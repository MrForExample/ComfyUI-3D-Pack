
__version__ = (0, 1, 4)
__version_str__ = ".".join(map(str, __version__))
